package com.ichat.offline

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ichat.offline.data.*
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()

    val chats: StateFlow<List<ChatEntity>> =
        dao.chats().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _current = MutableStateFlow<Long?>(null)
    val currentId: StateFlow<Long?> = _current

    val messages: StateFlow<List<MessageEntity>> = _current
        .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.messages(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun open(id: Long) { _current.value = id }
    fun newChat() { _current.value = null }

    fun send(text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            var id = _current.value
            if (id == null) {
                id = dao.insertChat(ChatEntity(title = clean.take(40), updatedAt = now))
                _current.value = id
            }
            dao.insertMessage(MessageEntity(chatId = id, role = "user", content = clean, createdAt = now))
            // المرحلة 1: لا يوجد محرك ذكاء اصطناعي بعد. نعرض تنبيهًا صريحًا بدل رد مزيف.
            dao.insertMessage(
                MessageEntity(
                    chatId = id, role = "system", createdAt = now + 1,
                    content = "محرك الذكاء الاصطناعي لم يُدمج بعد (المرحلة 2). رسالتك محفوظة في السجل."
                )
            )
            dao.touch(id, now)
        }
    }

    fun deleteChat(id: Long) {
        viewModelScope.launch {
            if (_current.value == id) _current.value = null
            dao.deleteChat(id)
        }
    }

    fun deleteAll() {
        viewModelScope.launch { _current.value = null; dao.deleteAll() }
    }
}
