package com.ichat.offline.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Part(val isCode: Boolean, val text: String, val lang: String)

private fun splitFences(src: String): List<Part> {
    val out = mutableListOf<Part>()
    val buf = StringBuilder()
    var inCode = false
    var lang = ""
    for (line in src.lines()) {
        if (line.trimStart().startsWith("```")) {
            if (inCode) {
                out += Part(true, buf.toString().trimEnd('\n'), lang)
                buf.clear(); inCode = false
            } else {
                if (buf.isNotBlank()) out += Part(false, buf.toString().trimEnd('\n'), "")
                buf.clear(); inCode = true
                lang = line.trimStart().removePrefix("```").trim()
            }
        } else buf.append(line).append('\n')
    }
    if (buf.isNotBlank()) out += Part(inCode, buf.toString().trimEnd('\n'), if (inCode) lang else "")
    return out
}

private val inlineRegex = Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`")

private fun inline(text: String): AnnotatedString = buildAnnotatedString {
    var last = 0
    for (m in inlineRegex.findAll(text)) {
        append(text.substring(last, m.range.first))
        if (m.groupValues[1].isNotEmpty()) {
            withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
        } else {
            withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33888888))) {
                append(m.groupValues[2])
            }
        }
        last = m.range.last + 1
    }
    append(text.substring(last))
}

@Composable
fun Markdown(text: String) {
    val parts = remember(text) { splitFences(text) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        for (p in parts) if (p.isCode) CodeBlock(p.text, p.lang) else TextBlock(p.text)
    }
}

@Composable
private fun TextBlock(text: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        for (raw in text.lines()) {
            val line = raw.trimEnd()
            if (line.isBlank()) { Spacer(Modifier.height(4.dp)); continue }
            val h = Regex("^(#{1,3})\\s+(.*)").find(line)
            when {
                h != null -> Text(
                    inline(h.groupValues[2]),
                    fontWeight = FontWeight.Bold,
                    fontSize = when (h.groupValues[1].length) { 1 -> 22.sp; 2 -> 19.sp; else -> 17.sp }
                )
                line.trimStart().startsWith("- ") || line.trimStart().startsWith("* ") ->
                    Text(inline("• " + line.trimStart().drop(2)))
                else -> Text(inline(line))
            }
        }
    }
}

@Composable
private fun CodeBlock(code: String, lang: String) {
    val clipboard = LocalClipboardManager.current
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
            Column {
                Row(
                    Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(lang.ifBlank { "code" }, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    TextButton(onClick = { clipboard.setText(AnnotatedString(code)) }) { Text("نسخ") }
                }
                Text(
                    code,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    modifier = Modifier.horizontalScroll(rememberScrollState()).padding(start = 12.dp, end = 12.dp, bottom = 12.dp)
                )
            }
        }
    }
}
