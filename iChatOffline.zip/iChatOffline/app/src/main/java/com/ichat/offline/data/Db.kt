package com.ichat.offline.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val updatedAt: Long
)

@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(entity = ChatEntity::class, parentColumns = ["id"], childColumns = ["chatId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("chatId")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val chatId: Long,
    val role: String, // "user" | "assistant" | "system"
    val content: String,
    val createdAt: Long
)

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats ORDER BY updatedAt DESC") fun chats(): Flow<List<ChatEntity>>
    @Query("SELECT * FROM messages WHERE chatId = :chatId ORDER BY id") fun messages(chatId: Long): Flow<List<MessageEntity>>
    @Insert suspend fun insertChat(c: ChatEntity): Long
    @Insert suspend fun insertMessage(m: MessageEntity): Long
    @Update suspend fun updateMessage(m: MessageEntity)
    @Query("UPDATE chats SET updatedAt = :t WHERE id = :id") suspend fun touch(id: Long, t: Long)
    @Query("DELETE FROM chats WHERE id = :id") suspend fun deleteChat(id: Long)
    @Query("DELETE FROM chats") suspend fun deleteAll()
}

@Database(entities = [ChatEntity::class, MessageEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): ChatDao

    companion object {
        @Volatile private var instance: AppDb? = null
        fun get(context: Context): AppDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDb::class.java, "ichat.db")
                .build().also { instance = it }
        }
    }
}
